---------creating Summary-------------------
CREATE VIEW support_summary AS
SELECT
    account_id,
    COUNT(*) AS total_tickets,
    AVG(satisfaction_score) AS avg_satisfaction,
    AVG(resolution_time_hours) AS avg_resolution_time,
    SUM(
        CASE
            WHEN escalation_flag = TRUE THEN 1
            ELSE 0
        END
    ) AS escalated_tickets
FROM support_tickets
GROUP BY account_id;


------creating feature summary ---------------

CREATE VIEW feature_summary AS
SELECT
    s.account_id,
    SUM(f.usage_count) AS total_feature_usage,
    COUNT(DISTINCT f.feature_name) AS unique_features_used,
    SUM(f.usage_duration_secs) AS total_usage_duration,
    SUM(f.error_count) AS total_errors
FROM feature_usage f
JOIN subscriptions s
    ON f.subscription_id = s.subscription_id
GROUP BY s.account_id;

------creating churn summary --------------
CREATE VIEW churn_summary AS
SELECT
    account_id,
    COUNT(*) AS churn_events
FROM churn_events
GROUP BY account_id;
----creating customer_360 summary-----------
CREATE VIEW customer_360 AS
SELECT
    a.account_id,
    a.account_name,
    a.industry,
    a.country,
    a.plan_tier,
    a.seats,
    a.churn_flag,

    s.mrr_amount,
    s.arr_amount,
    s.billing_frequency,
    s.auto_renew_flag,

    fs.total_feature_usage,
    fs.unique_features_used,
    fs.total_usage_duration,
    fs.total_errors,

    ss.total_tickets,
    ss.avg_satisfaction,
    ss.avg_resolution_time,
    ss.escalated_tickets

FROM accounts a
LEFT JOIN subscriptions s
    ON a.account_id = s.account_id
LEFT JOIN feature_summary fs
    ON a.account_id = fs.account_id
LEFT JOIN support_summary ss
    ON a.account_id = ss.account_id;

select * from customer_360 limit 10;
