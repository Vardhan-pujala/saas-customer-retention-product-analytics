-------------------------------------Cohort Analysis-----------------------------------------
----CH1:Cohort Retention Overview
SELECT
    DATE_TRUNC('month', signup_date)::date AS cohort_month,
    COUNT(*) AS customers
FROM accounts
GROUP BY cohort_month
ORDER BY cohort_month;

SELECT
    DATE_TRUNC('month', signup_date)::date AS cohort_month,
    COUNT(*) AS total_customers,

    SUM(
        CASE
            WHEN churn_flag = FALSE THEN 1
            ELSE 0
        END
    ) AS retained_customers,

    ROUND(
        100.0 *
        SUM(
            CASE
                WHEN churn_flag = FALSE THEN 1
                ELSE 0
            END
        ) / COUNT(*),
        2
    ) AS retention_rate
FROM accounts
GROUP BY cohort_month
ORDER BY cohort_month;
/* Findings:
Customer retention improved from approximately 76% in 2023 to 81% in 2024, indicating better customer quality and engagement over time.
The highest retention was observed in the December 2024 cohort (94.12%), while the September 2024 cohort showed the lowest retention (64.00%).
Cohorts acquired during the second half of 2024 consistently outperformed earlier cohorts, suggesting successful improvements in acquisition, onboarding, or product experience.*/

--CH2:Chorot Revenue Analysis
SELECT
    DATE_TRUNC('month', a.signup_date)::date AS cohort_month,
    ROUND(AVG(s.mrr_amount),2) AS avg_mrr,
    ROUND(AVG(s.arr_amount),2) AS avg_arr
FROM accounts a
JOIN subscriptions s
    ON a.account_id = s.account_id
GROUP BY cohort_month
ORDER BY cohort_month;
---Business Insight: Recent cohorts are not only retaining better but also generating higher recurring revenue, suggesting successful improvements in customer acquisition and product value delivery.

--ch3: WHICH CHOROTS ARE MORE ENGAGED?
SELECT
    DATE_TRUNC('month', a.signup_date)::date AS cohort_month,
    ROUND(AVG(fs.total_feature_usage),2) AS avg_feature_usage
FROM accounts a
JOIN feature_summary fs
    ON a.account_id = fs.account_id
GROUP BY cohort_month
ORDER BY cohort_month;
---BUSINESS INSIGHT: MOST CHOROTS SHOW APPORXIMATERLY ENGAGEMENT MEANS PRODUCT IS WORKING GOOD. WHILE 2024 COHORTS SHOW MORE ENGAGEMENT THAN 2023.
------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
