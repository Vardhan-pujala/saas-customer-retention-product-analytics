-- Now we do retention driver analysis --
--RH1: Does beta feature adoption improve retention?
SELECT
    is_beta_feature,
    ROUND(
        AVG(
            CASE
                WHEN a.churn_flag = FALSE THEN 1
                ELSE 0
            END
        ) * 100,
        2
    ) AS retention_rate
FROM feature_usage f
JOIN subscriptions s
    ON f.subscription_id = s.subscription_id
JOIN accounts a
    ON s.account_id = a.account_id
GROUP BY is_beta_feature;
--findings: Adopting beta feature is not reason main reason for high retention.


--RH2: do customer support satisfaction caused retention.
SELECT
    churn_flag,
    ROUND(AVG(avg_satisfaction),2) AS avg_satisfaction
FROM customer_360
GROUP BY churn_flag;
--Findigs: Not really. Between yes and No there is no massive difference.--

--RH3:Do customers receiving faster support retain better?--
SELECT
    churn_flag,
    ROUND(AVG(avg_resolution_time),2) AS avg_resolution_time
FROM customer_360
GROUP BY churn_flag;
--Findings: Not really, it didn't show major impact on churn --


--RH4:Do customers who enable auto-renew retain longer?
SELECT
    auto_renew_flag,
    COUNT(*) AS customers,
    ROUND(
        AVG(
            CASE
                WHEN churn_flag = FALSE THEN 1
                ELSE 0
            END
        ) * 100,
        2
    ) AS retention_rate
FROM customer_360
GROUP BY auto_renew_flag;
--Findings:Not really it is showing really minial impact on retention.
---------------------------------------------------------------------------------------------
