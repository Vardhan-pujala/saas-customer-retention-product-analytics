CREATE TABLE accounts (
    account_id VARCHAR(50) PRIMARY KEY,
    account_name VARCHAR(255),
    industry VARCHAR(100),
    country VARCHAR(100),
    signup_date DATE,
    referral_source VARCHAR(100),
    plan_tier VARCHAR(50),
    seats INTEGER,
    is_trial BOOLEAN,
    churn_flag BOOLEAN
);
CREATE TABLE subscriptions (
    subscription_id VARCHAR(50) PRIMARY KEY,
    account_id VARCHAR(50),
    start_date DATE,
    end_date DATE,
    plan_tier VARCHAR(50),
    seats INTEGER,
    mrr_amount NUMERIC(12,2),
    arr_amount NUMERIC(12,2),
    is_trial BOOLEAN,
    upgrade_flag BOOLEAN,
    downgrade_flag BOOLEAN,
    churn_flag BOOLEAN,
    billing_frequency VARCHAR(50),
    auto_renew_flag BOOLEAN
);

CREATE TABLE feature_usage (
    usage_id VARCHAR(50) PRIMARY KEY,
    subscription_id VARCHAR(50),
    usage_date DATE,
    feature_name VARCHAR(255),
    usage_count INTEGER,
    usage_duration_secs INTEGER,
    error_count INTEGER,
    is_beta_feature BOOLEAN
);

CREATE TABLE support_tickets (
    ticket_id VARCHAR(50) PRIMARY KEY,
    account_id VARCHAR(50),
    submitted_at TIMESTAMP,
    closed_at TIMESTAMP,
    resolution_time_hours NUMERIC(10,2),
    priority VARCHAR(50),
    first_response_time_minutes NUMERIC(10,2),
    satisfaction_score NUMERIC(5,2),
    escalation_flag BOOLEAN
);

CREATE TABLE churn_events (
    churn_event_id VARCHAR(50) PRIMARY KEY,
    account_id VARCHAR(50),
    churn_date DATE,
    reason_code VARCHAR(255),
    refund_amount_usd NUMERIC(12,2),
    preceding_upgrade_flag BOOLEAN,
    preceding_downgrade_flag BOOLEAN,
    is_reactivation BOOLEAN,
    feedback_text TEXT
);
SELECT table_name
FROM information_schema.views
WHERE table_schema = 'public';


