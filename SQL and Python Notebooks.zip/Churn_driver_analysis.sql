------------------------------Churn Driver Analysis------------------------------------------
--we run hypothesis testing on possible way.
--Hypothesis 1: do some plane makes churn.
   SELECT
    plan_tier,
    COUNT(*) AS customers,
    SUM(CASE WHEN churn_flag = TRUE THEN 1 ELSE 0 END) AS churned_customers,
    ROUND(
        100.0 * SUM(CASE WHEN churn_flag = TRUE THEN 1 ELSE 0 END) / COUNT(*),
        2
    ) AS churn_rate
FROM accounts
GROUP BY plan_tier
ORDER BY churn_rate DESC;
-- so the Enterprise customers show more churn rate.

--Hypothesis 2: which industries churn more
SELECT
    industry,
    COUNT(*) AS customers,
    SUM(CASE WHEN churn_flag = TRUE THEN 1 ELSE 0 END) AS churned_customers,
    ROUND(
        100.0 * SUM(CASE WHEN churn_flag = TRUE THEN 1 ELSE 0 END) / COUNT(*),
        2
    ) AS churn_rate
FROM accounts
GROUP BY industry
ORDER BY churn_rate DESC;
-- Findings: DevTools industry show high churn rate.
--Hypothesis 3: Do Trail customer churn more.
SELECT
    is_trial,
    COUNT(*) AS customers,
    SUM(CASE WHEN churn_flag = TRUE THEN 1 ELSE 0 END) AS churned_customers,
    ROUND(
        100.0 * SUM(CASE WHEN churn_flag = TRUE THEN 1 ELSE 0 END) / COUNT(*),
        2
    ) AS churn_rate
FROM accounts
GROUP BY is_trial;

-- yes Trail customers are show more churn rate than paid cutomers

-- Hypothesis 4:Do customers with fewer seats churn more?
SELECT
    churn_flag,
    ROUND(AVG(seats),2) AS avg_seats
FROM accounts
GROUP BY churn_flag;

/*Findings:Churned accounts had a lower average seat count, 
with 19.24 seats compared to 20.93 seats for retained accounts. 
This indicates that smaller accounts may be somewhat more prone to churn, 
though the difference is relatively small.*/

