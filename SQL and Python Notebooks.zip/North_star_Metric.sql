-----------------------------------FINDING NORTH STAR METRICS--------------------------------------------------------------------
--ANALYSIS1:
SELECT
    churn_flag,
    ROUND(AVG(total_feature_usage),2) AS avg_usage
FROM customer_360
GROUP BY churn_flag;
--ANALYSIS2:
SELECT
    churn_flag,
    ROUND(AVG(unique_features_used),2) AS avg_features
FROM customer_360
GROUP BY churn_flag;
--ANALYSIS3:
SELECT
    churn_flag,
    ROUND(AVG(total_usage_duration),2) AS avg_duration
FROM customer_360
GROUP BY churn_flag;
--ANALYSIS4:
SELECT
    churn_flag,
    ROUND(AVG(seats),2) AS avg_seats
FROM customer_360
GROUP BY churn_flag;
--CONCLUSIONS FROM 4 ANALYSIS
/*Total feature usage, feature diversity, and usage duration did not show a strong positive relationship with retention, as churned customers exhibited similar or higher engagement levels than retained customers.
Seat count showed only a weak positive association with retention, indicating that larger accounts were slightly more likely to stay.
No single engagement metric emerged as a clear North Star Metric, suggesting that product activity alone does not explain long-term customer success.
Future analysis should focus on feature-specific value, customer satisfaction, and business outcomes to identify a more meaningful North Star Metric for the product.*/

