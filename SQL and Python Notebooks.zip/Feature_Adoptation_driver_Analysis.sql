-----------------------------FEATURE ADOPTATION DRIVER ANALYSIS----------------------------------------------------------------------------------------------------------------------------------------------------------
--FH1: WHICH FEATURE IS MOST ENGAGED
SELECT
    feature_name,
    SUM(usage_count) AS total_usage
FROM feature_usage
GROUP BY feature_name
ORDER BY total_usage DESC;
--FINDINGS: FEATURE 32 IS HIGHEST USAGE AND FEATURE 23 IS LOWEST USAGE.
--FH2:WHICH FEATURE SHOW MORE RETENTION
SELECT
    f.feature_name,
    ROUND(
        AVG(
            CASE
                WHEN a.churn_flag = FALSE THEN 1
                ELSE 0
            END
        ) * 100,
        2
    ) AS retention_rate
FROM feature_usage f
JOIN subscriptions s
    ON f.subscription_id = s.subscription_id
JOIN accounts a
    ON s.account_id = a.account_id
GROUP BY f.feature_name
ORDER BY retention_rate DESC;
/*FINDINGS:EVEN THOUGH FEATURE 23 HAS LOWEST USAGE BUT IT SHOW HIGH RETENTION.MAYBE 
THIS FEATURE IS UNEXPLORED BUT SHOWS RETENTION. PROMOTE MORE ABOUT THIS FEATURE.*/
--FH3: FEATURE ERRORS
SELECT
    feature_name,
    SUM(error_count) AS total_errors
FROM feature_usage
GROUP BY feature_name
ORDER BY total_errors DESC;
--FINDINGS: ALL FEATURES SHOW AVERAGELY 352 ERRORS. TRY TO FIX ALL ERROS
-----------------------------------------------------------------------------------------------------------------------
